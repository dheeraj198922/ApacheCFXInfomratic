package com.java.informatics.cxfclient;

import java.net.MalformedURLException;
import java.net.URL;

import org.tempuri.Calculator;
import org.tempuri.CalculatorSoap;

public class CalculatorCleint {
	public static void main(String[] args) {
		try {
			Calculator calculator = new Calculator(new URL("http://www.dneonline.com/calculator.asmx?wsdl"));
			CalculatorSoap calculatorSoap = calculator.getCalculatorSoap();
			int sum = calculatorSoap.add(2, 3);
			System.out.println("sum ::"+sum);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
}
